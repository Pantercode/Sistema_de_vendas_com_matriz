

def rodar_pocobuser():
    '''
    Função de criação matriz onde são inseridas linhas e colunas em uma lista para elaborar
    a matriz.
    :return: Corredor(XX), Motorista(MM).
    '''


    onibus = cria_matriz(8, 5)
    for l in range(len(onibus)):
        onibus[l][2] = "XX"
    for p in range(len(onibus[0])):
        onibus[0][p] = "XX"
    onibus[0][0] = "MM"

    total = disponiveis(onibus)
    reservados = []
    livres = disponiveis(onibus)

    while True:
        print('\033[36m==\033[m'*20)
        print('\033[36m ______SISTEMA DE VENDA POCCOBUS______  \033[m')
        print('\033[36m==\033[m'*20)

        resp = str(input('Deseja reservar uma passagem [S/N]').upper().strip()[0])

        if resp == 'N':
            print('Saindo.....')
            print('Volte Sempre!')

            break

        else:
            for c in range(len(onibus)):
                    print(onibus[c])
            cores_matriz(onibus, livres)
            cadeira = str(input('Escolha sua cadeira: '))
            if cadeira not in total:
                print("Assento não existe")
            elif cadeira in reservados:
                print("Reservado")
            elif cadeira in livres:
                onibus = edita_matriz(onibus, cadeira)
                reservados.append(cadeira)
                print(livres)
                livres.remove(cadeira)
                print(livres)
                relatorio_txt(reservados, livres)

            else:
                print('Assento Inexistente')



    relatorio_txt(reservados, livres)
    return disponiveis

def cria_matriz(nlinhas, ncolunas):
    '''
    Está função  inicia o ônibus da PoccoBus que cria uma matriz com motorista , espaços sem assento e
    também com os assentos dísponíveis para compra sendo no total de 28 assentos para venda e compra.
    :returns uma lista de listas contendo os assentos dísponíveis.
    '''
    matriz = []
    for i in range(nlinhas):
        linha = []
        for cont in range(ncolunas):
            linha.append(f'{i}{cont}')
        matriz.append(linha)
    return matriz


def edita_matriz(matriz, cadeiras):
    '''
    Função que edita matriz percorrendo tamanho da matriz informando após a compra assento ocupado pela matriz
    :returns  Oc(Assento ocupado)
    '''
    for i in range(len(matriz)):
        for cont in range(len(matriz[i])):
            if cadeiras == matriz[i][cont]:
                matriz[i][cont] = 'OC'
    return matriz


def disponiveis(matriz):
    '''
    Função que verifica na matriz bancos disponiveis para a venda e informando ou não a possibilidade
    para a venda ou não.
    '''
    vagos = []
    for i in range(len(matriz)):
        for cont in range(len(matriz[i])):
            if matriz[i][cont] != "XX" and matriz[i][cont] != "MM" and matriz[i][cont] != "OC":
                vagos.append(f'{i}{cont}')
    return vagos




def cores_matriz(onibus, disponiveis):
    '''
    Insere as cores as bancos ocupados e ao corredor e também ao motorista.
    '''

    for cont in range(len(onibus)):
        base_colors = []
        for contb in range(len(onibus[cont])):
            if onibus[cont][contb] in disponiveis:
                base_colors.append(f'\033[0;40;32m{onibus[cont][contb]}\033[m')
            elif onibus[cont][contb] == 'OC':
                base_colors.append(f'\033[0;40;41m{onibus[cont][contb]}\033[m')
            elif onibus[cont][contb] == 'XX':
                base_colors.append(f'\033[0;40;47mXX\033[m')
            else:
                base_colors.append(f'\033[0;40;36m{onibus[cont][contb]}\033[m')
        print('|' + " " .join([f'{base_colors[c]}' for c in range(len(base_colors))]) + '|')


def relatorio_txt(reservados,disponiveis):
    '''
    Funçao imprime relatorio com assentos
     disponiveis e indisponiveis.

    '''
    relatorio = open("relatorio.txt", mode="w")
    #relatorio.write(cabec)

    relatorio.write("\n")
    relatorio.write("Reservados: ")
    for item in reservados:
        relatorio.write(item)
        relatorio.write(", ")

    relatorio.write("\n")
    relatorio.write("Disponiveis: ")
    for item in disponiveis:
        relatorio.write(item)
        relatorio.write(", ")


rodar_pocobuser()

